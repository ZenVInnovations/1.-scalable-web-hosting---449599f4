<section class="p-12 text-center">
  <h1 class="font-extrabold pb-4 lg:text-4xl md:text-2xl">
    Epic Web Application
  </h1>
  <p class="text-gray-500 lg:text-lg md:text-md">
    Like many epic web applications, this one too has a Hero element.
  </p>
</section>
