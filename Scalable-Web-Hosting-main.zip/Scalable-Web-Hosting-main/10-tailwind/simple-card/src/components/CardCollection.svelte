<script>
  import Card from "./Card.svelte";
</script>

<section class="container mx-auto grid md:grid-cols-2 lg:grid-cols-3 gap-2">
  <Card />
  <Card />
  <Card />
  <Card />
  <Card />
  <Card />
  <Card />
  <Card />
</section>
