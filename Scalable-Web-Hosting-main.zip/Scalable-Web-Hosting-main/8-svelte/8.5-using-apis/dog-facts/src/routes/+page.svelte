<script>
  import JokeApi from "../components/JokeApi.svelte";
  import DogFacts from "../components/DogFacts.svelte";
</script>

<DogFacts />