<script>
	import Hello from '../components/Hello.svelte';
</script>

<h1>Welcome to SvelteKit</h1>
<Hello />
