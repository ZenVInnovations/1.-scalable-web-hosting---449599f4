<script>
	let message = 'Hello yo';
</script>

<p>{message}!</p>