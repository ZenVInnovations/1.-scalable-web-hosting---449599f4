<script>
  import InputStatistics from '../components/InputStatistics.svelte';
</script>


<InputStatistics />