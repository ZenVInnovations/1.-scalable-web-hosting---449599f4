<script>
  import Monitor from '../components/Monitor.svelte';
</script>


<Monitor />