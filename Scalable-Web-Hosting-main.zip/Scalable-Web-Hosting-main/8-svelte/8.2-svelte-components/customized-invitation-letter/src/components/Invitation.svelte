<script>
	export let name;
</script>

<p>Dear {name},</p>
<p><slot /></p>
