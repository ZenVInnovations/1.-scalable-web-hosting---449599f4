<script>
	import Invitation from '../components/Invitation.svelte';
</script>

<Invitation name="Alice">
  We cordially invite you to the party!
</Invitation>
