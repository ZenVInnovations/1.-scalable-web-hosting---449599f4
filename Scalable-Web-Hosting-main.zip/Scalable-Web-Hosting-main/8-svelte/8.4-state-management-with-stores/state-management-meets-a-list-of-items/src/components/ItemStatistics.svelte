<script>
  import { items } from "./itemStore.js";
</script>

<p>Total items: {$items.length}</p>
