<script>
  import ItemInput from "./ItemInput.svelte";
  import ItemList from "./ItemList.svelte";
  import ItemStatistics from "./ItemStatistics.svelte";
</script>

<h1>Items app</h1>

<ItemStatistics />

<ItemInput />

<ItemList />