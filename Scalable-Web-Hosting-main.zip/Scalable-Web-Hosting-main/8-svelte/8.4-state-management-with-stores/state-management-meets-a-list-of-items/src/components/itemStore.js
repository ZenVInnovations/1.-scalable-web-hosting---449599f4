import { writable } from 'svelte/store';

const items = writable([]);

export { items };