<script>
	import ItemApp from "../components/ItemApp.svelte";
</script>

<ItemApp />
