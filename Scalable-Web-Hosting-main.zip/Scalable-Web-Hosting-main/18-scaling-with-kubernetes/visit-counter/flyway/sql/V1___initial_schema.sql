CREATE TABLE visit_log (
  id SERIAL PRIMARY KEY,
  created_at TIMESTAMP
);
