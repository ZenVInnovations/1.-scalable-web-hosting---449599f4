<script>
  import ServerSentJSONEvents from "../components/ServerSentJSONEvents.svelte";
</script>

<ServerSentJSONEvents />