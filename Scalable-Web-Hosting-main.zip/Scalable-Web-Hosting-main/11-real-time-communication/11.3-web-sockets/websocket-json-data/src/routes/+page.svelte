<script>
  import WebscoketSentJSONEvents from "../components/WebscoketSentJSONEvents.svelte";
</script>

<WebscoketSentJSONEvents />